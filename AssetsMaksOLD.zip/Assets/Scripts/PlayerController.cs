using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] float mouseSense = 1;
    [SerializeField] Transform Body;
    [SerializeField] CharacterController controller;
    [SerializeField] float speed = 10f;
    [SerializeField] float gravity = 50f;
    [SerializeField] float jumpf = 30f;
    [SerializeField] float minXRotation = -70f;
    [SerializeField] float maxXRotation = 70f;
    [SerializeField] Animator CameraAnim;
    [SerializeField] GameObject Crosshair;

    private float currentXRotation = 0f;
    Vector3 direction;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    private void Disable()
    {
        CameraAnim.enabled = false;
        Crosshair.SetActive(true);
    }

    void Update()
    {
        Quaternion cameraRotation = transform.rotation;
        float yRotation = cameraRotation.eulerAngles.y;
        Quaternion newRotation = Quaternion.Euler(0, yRotation, 0);
        Body.transform.rotation = newRotation;

        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        if (controller.isGrounded)
        {
            direction = new Vector3(moveHorizontal, 0, moveVertical);
            direction = Body.transform.TransformDirection(direction) * speed;
        }
        direction.y -= gravity * Time.deltaTime;
        controller.Move(direction * Time.deltaTime);

        transform.position = new Vector3(Body.position.x, Body.position.y + 1, Body.position.z);

        float rotateX = Input.GetAxis("Mouse X") * mouseSense;
        float rotateY = Input.GetAxis("Mouse Y") * mouseSense;

        currentXRotation -= rotateY;
        currentXRotation = Mathf.Clamp(currentXRotation, minXRotation, maxXRotation);

        Vector3 rotPlayer = transform.rotation.eulerAngles;
        rotPlayer.x = currentXRotation;
        rotPlayer.z = 0;
        rotPlayer.y += rotateX;
        transform.rotation = Quaternion.Euler(rotPlayer);
    }
}
